import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import CollegeFinder from './pages/CollegeFinder';
import Admissions from './pages/Admissions';
import About from './pages/About';
import CareerPaths from './pages/CareerPaths';
import Exams from './pages/Exams';
import Courses from './pages/Courses';
import Scholarships from './pages/Scholarships';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/colleges" element={<CollegeFinder />} />
            <Route path="/admissions" element={<Admissions />} />
            <Route path="/about" element={<About />} />
            <Route path="/careers" element={<CareerPaths />} />
            <Route path="/exams" element={<Exams />} />
            <Route path="/courses" element={<Courses />} />
            <Route path="/scholarships" element={<Scholarships />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
