import React, { useState } from 'react';
import PageTransition from '../components/PageTransition';
import { BookOpen, Clock, DollarSign, GraduationCap, TrendingUp, ChevronRight, Search, Layers } from 'lucide-react';
import './Courses.css';

const streams = [
    { id: 'all', label: 'All Streams' },
    { id: 'engineering', label: 'Engineering' },
    { id: 'medical', label: 'Medical' },
    { id: 'arts', label: 'Arts & Humanities' },
    { id: 'science', label: 'Science' },
    { id: 'commerce', label: 'Commerce' },
    { id: 'law', label: 'Law' },
];

const courses = [
    {
        id: 1, name: 'B.Tech (Computer Science)', stream: 'engineering', duration: '4 Years',
        degree: 'Bachelor of Technology', avgFees: '₹1.5 - 6 Lacs/yr', topColleges: 120,
        trending: true, color: '#4F46E5',
        highlights: ['AI & ML Specialization', 'Industry Internships', 'High Placement Rate'],
    },
    {
        id: 2, name: 'MBBS', stream: 'medical', duration: '5.5 Years',
        degree: 'Bachelor of Medicine & Surgery', avgFees: '₹2 - 25 Lacs/yr', topColleges: 85,
        trending: true, color: '#06B6D4',
        highlights: ['Clinical Rotations', 'Government Seats', 'Global Recognition'],
    },
    {
        id: 3, name: 'BA LLB (Hons)', stream: 'law', duration: '5 Years',
        degree: 'Integrated Law Degree', avgFees: '₹1 - 5 Lacs/yr', topColleges: 50,
        trending: false, color: '#D97706',
        highlights: ['Moot Court Practice', 'Legal Internships', 'Corporate Law Focus'],
    },
    {
        id: 4, name: 'BBA', stream: 'commerce', duration: '3 Years',
        degree: 'Bachelor of Business Administration', avgFees: '₹1 - 4 Lacs/yr', topColleges: 95,
        trending: false, color: '#F43F5E',
        highlights: ['Entrepreneurship Track', 'Industry Projects', 'MBA Pathway'],
    },
    {
        id: 5, name: 'B.Sc (Data Science)', stream: 'science', duration: '3 Years',
        degree: 'Bachelor of Science', avgFees: '₹1 - 3 Lacs/yr', topColleges: 60,
        trending: true, color: '#059669',
        highlights: ['Python & R Programming', 'Real-world Datasets', 'Industry Certifications'],
    },
    {
        id: 6, name: 'BA (Psychology)', stream: 'arts', duration: '3 Years',
        degree: 'Bachelor of Arts', avgFees: '₹0.5 - 2 Lacs/yr', topColleges: 70,
        trending: false, color: '#8B5CF6',
        highlights: ['Clinical Psychology', 'Counseling Training', 'Research Methods'],
    },
    {
        id: 7, name: 'B.Tech (Mechanical)', stream: 'engineering', duration: '4 Years',
        degree: 'Bachelor of Technology', avgFees: '₹1.2 - 5 Lacs/yr', topColleges: 110,
        trending: false, color: '#4F46E5',
        highlights: ['CAD/CAM', 'Robotics', 'Core Industry Placements'],
    },
    {
        id: 8, name: 'B.Com (Hons)', stream: 'commerce', duration: '3 Years',
        degree: 'Bachelor of Commerce', avgFees: '₹0.5 - 3 Lacs/yr', topColleges: 130,
        trending: false, color: '#F43F5E',
        highlights: ['CA Foundation Ready', 'Financial Accounting', 'Tax & Audit'],
    },
    {
        id: 9, name: 'B.Pharm', stream: 'medical', duration: '4 Years',
        degree: 'Bachelor of Pharmacy', avgFees: '₹1 - 4 Lacs/yr', topColleges: 75,
        trending: false, color: '#06B6D4',
        highlights: ['Drug Research', 'Pharma Industry', 'Hospital Training'],
    },
];

const Courses = () => {
    const [activeStream, setActiveStream] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');

    const filteredCourses = courses.filter(course => {
        const matchesStream = activeStream === 'all' || course.stream === activeStream;
        const matchesSearch = course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            course.degree.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesStream && matchesSearch;
    });

    const trendingCourses = courses.filter(c => c.trending);

    return (
        <PageTransition>
            <div className="courses-page">
                {/* Hero */}
                <section className="courses-hero">
                    <div className="container">
                        <div className="courses-hero-content">
                            <span className="badge"><Layers size={16} /> Browse Courses</span>
                            <h1 className="text-gradient">Explore Courses That Shape Careers</h1>
                            <p className="subtitle">
                                Discover degree programs across every stream — compare fees, duration, and top-ranked colleges offering them.
                            </p>

                            <div className="courses-search-bar">
                                <Search className="icon" size={20} />
                                <input
                                    type="text"
                                    placeholder="Search courses by name or degree type..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                        </div>
                    </div>
                </section>

                {/* Trending */}
                <section className="trending-section">
                    <div className="container">
                        <div className="section-header">
                            <h2>🔥 Trending Courses</h2>
                        </div>
                        <div className="trending-row">
                            {trendingCourses.map(course => (
                                <div key={course.id} className="trending-chip" style={{ '--accent': course.color }}>
                                    <TrendingUp size={16} color={course.color} />
                                    <span>{course.name}</span>
                                    <ChevronRight size={14} />
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Stream Tabs */}
                <section className="courses-tabs-section">
                    <div className="container">
                        <div className="courses-tab-bar">
                            {streams.map(stream => (
                                <button
                                    key={stream.id}
                                    className={`course-tab-btn ${activeStream === stream.id ? 'active' : ''}`}
                                    onClick={() => setActiveStream(stream.id)}
                                >
                                    {stream.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Course Cards */}
                <section className="courses-results">
                    <div className="container">
                        <div className="courses-results-header">
                            <h3>Showing {filteredCourses.length} Courses</h3>
                        </div>

                        <div className="courses-grid">
                            {filteredCourses.map(course => (
                                <div key={course.id} className="course-card" style={{ '--accent': course.color }}>
                                    <div className="course-card-top">
                                        <div className="course-icon-wrap" style={{ background: `${course.color}15`, color: course.color }}>
                                            <GraduationCap size={24} />
                                        </div>
                                        {course.trending && (
                                            <span className="trending-badge">
                                                <TrendingUp size={12} /> Trending
                                            </span>
                                        )}
                                    </div>

                                    <h3>{course.name}</h3>
                                    <p className="course-degree">{course.degree}</p>

                                    <div className="course-meta-grid">
                                        <div className="course-meta-item">
                                            <Clock size={15} />
                                            <div>
                                                <span className="meta-label">Duration</span>
                                                <strong>{course.duration}</strong>
                                            </div>
                                        </div>
                                        <div className="course-meta-item">
                                            <DollarSign size={15} />
                                            <div>
                                                <span className="meta-label">Avg Fees</span>
                                                <strong>{course.avgFees}</strong>
                                            </div>
                                        </div>
                                        <div className="course-meta-item">
                                            <BookOpen size={15} />
                                            <div>
                                                <span className="meta-label">Top Colleges</span>
                                                <strong>{course.topColleges}+</strong>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="course-highlights">
                                        {course.highlights.map(h => (
                                            <span key={h} className="highlight-tag" style={{ borderColor: `${course.color}40`, color: course.color }}>
                                                {h}
                                            </span>
                                        ))}
                                    </div>

                                    <button className="btn-explore" style={{ background: course.color }}>
                                        View Details <ChevronRight size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </div>
        </PageTransition>
    );
};

export default Courses;
