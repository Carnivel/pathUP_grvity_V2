import React, { useState } from 'react';
import PageTransition from '../components/PageTransition';
import { Search, Calendar, Clock, Award, Users, FileText, ChevronRight, Filter, BookOpen } from 'lucide-react';
import './Exams.css';

const examCategories = [
    { id: 'all', label: 'All Exams' },
    { id: 'engineering', label: 'Engineering' },
    { id: 'medical', label: 'Medical' },
    { id: 'management', label: 'Management' },
    { id: 'law', label: 'Law' },
    { id: 'design', label: 'Design' },
    { id: 'civil', label: 'Civil Services' },
];

const exams = [
    {
        id: 1,
        name: 'JEE Main 2026',
        category: 'engineering',
        conductedBy: 'National Testing Agency (NTA)',
        date: 'April 2026',
        level: 'National',
        eligibility: 'Class 12 with PCM (min 75%)',
        mode: 'Computer Based Test',
        registrations: '12L+',
        color: '#4F46E5',
        fees: '₹650 - ₹1,600',
    },
    {
        id: 2,
        name: 'NEET UG 2026',
        category: 'medical',
        conductedBy: 'National Testing Agency (NTA)',
        date: 'May 2026',
        level: 'National',
        eligibility: 'Class 12 with PCB (min 50%)',
        mode: 'Pen & Paper',
        registrations: '20L+',
        color: '#06B6D4',
        fees: '₹1,600 - ₹1,700',
    },
    {
        id: 3,
        name: 'CAT 2026',
        category: 'management',
        conductedBy: 'IIM (Rotational)',
        date: 'November 2026',
        level: 'National',
        eligibility: 'Graduation with 50%',
        mode: 'Computer Based Test',
        registrations: '2.5L+',
        color: '#F43F5E',
        fees: '₹2,300 - ₹2,500',
    },
    {
        id: 4,
        name: 'CLAT 2026',
        category: 'law',
        conductedBy: 'Consortium of NLUs',
        date: 'December 2026',
        level: 'National',
        eligibility: 'Class 12 with 45%',
        mode: 'Computer Based Test',
        registrations: '70K+',
        color: '#D97706',
        fees: '₹4,000 - ₹4,500',
    },
    {
        id: 5,
        name: 'GATE 2026',
        category: 'engineering',
        conductedBy: 'IIT (Rotational)',
        date: 'February 2026',
        level: 'National',
        eligibility: 'B.Tech / B.E. final year or graduate',
        mode: 'Computer Based Test',
        registrations: '8L+',
        color: '#8B5CF6',
        fees: '₹1,700 - ₹1,800',
    },
    {
        id: 6,
        name: 'NID DAT 2026',
        category: 'design',
        conductedBy: 'National Institute of Design',
        date: 'January 2026',
        level: 'National',
        eligibility: 'Class 12 (any stream)',
        mode: 'Pen & Paper + Studio Test',
        registrations: '30K+',
        color: '#059669',
        fees: '₹3,000 - ₹3,500',
    },
    {
        id: 7,
        name: 'UPSC CSE 2026',
        category: 'civil',
        conductedBy: 'UPSC',
        date: 'June 2026',
        level: 'National',
        eligibility: 'Graduation in any discipline',
        mode: 'Pen & Paper',
        registrations: '10L+',
        color: '#DC2626',
        fees: '₹100 - ₹200',
    },
    {
        id: 8,
        name: 'JEE Advanced 2026',
        category: 'engineering',
        conductedBy: 'IIT (Rotational)',
        date: 'May 2026',
        level: 'National',
        eligibility: 'Qualified JEE Main (Top 2.5L)',
        mode: 'Computer Based Test',
        registrations: '1.6L+',
        color: '#4F46E5',
        fees: '₹2,800 - ₹2,900',
    },
];

const Exams = () => {
    const [activeCategory, setActiveCategory] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');

    const filteredExams = exams.filter(exam => {
        const matchesCategory = activeCategory === 'all' || exam.category === activeCategory;
        const matchesSearch = exam.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            exam.conductedBy.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    return (
        <PageTransition>
            <div className="exams-page">
                {/* Hero */}
                <section className="exams-hero">
                    <div className="container">
                        <div className="exams-hero-content">
                            <span className="badge"><BookOpen size={16} /> Entrance Exams</span>
                            <h1 className="text-gradient">Find Your Exam, Ace Your Future</h1>
                            <p className="subtitle">
                                Explore upcoming entrance exams, registration details, and eligibility criteria — all in one place.
                            </p>

                            <div className="exams-search-bar">
                                <Search className="icon" size={20} />
                                <input
                                    type="text"
                                    placeholder="Search exams by name or conducting body..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                                <button className="btn-primary">
                                    <Filter size={16} /> Search
                                </button>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Category Tabs */}
                <section className="exams-tabs-section">
                    <div className="container">
                        <div className="exams-tab-bar">
                            {examCategories.map(cat => (
                                <button
                                    key={cat.id}
                                    className={`exam-tab-btn ${activeCategory === cat.id ? 'active' : ''}`}
                                    onClick={() => setActiveCategory(cat.id)}
                                >
                                    {cat.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Exam Cards */}
                <section className="exams-results">
                    <div className="container">
                        <div className="exams-results-header">
                            <h3>Showing {filteredExams.length} Exams</h3>
                        </div>

                        <div className="exams-grid">
                            {filteredExams.map(exam => (
                                <div key={exam.id} className="exam-card" style={{ '--accent': exam.color }}>
                                    <div className="exam-card-top">
                                        <div className="exam-level-badge" style={{ background: `${exam.color}15`, color: exam.color }}>
                                            <Award size={14} /> {exam.level}
                                        </div>
                                        <span className="exam-mode">{exam.mode}</span>
                                    </div>

                                    <h3 className="exam-name">{exam.name}</h3>
                                    <p className="exam-body">{exam.conductedBy}</p>

                                    <div className="exam-details-grid">
                                        <div className="exam-detail">
                                            <Calendar size={16} />
                                            <div>
                                                <span className="detail-label">Exam Date</span>
                                                <strong>{exam.date}</strong>
                                            </div>
                                        </div>
                                        <div className="exam-detail">
                                            <Users size={16} />
                                            <div>
                                                <span className="detail-label">Registrations</span>
                                                <strong>{exam.registrations}</strong>
                                            </div>
                                        </div>
                                        <div className="exam-detail">
                                            <FileText size={16} />
                                            <div>
                                                <span className="detail-label">Eligibility</span>
                                                <strong>{exam.eligibility}</strong>
                                            </div>
                                        </div>
                                        <div className="exam-detail">
                                            <Clock size={16} />
                                            <div>
                                                <span className="detail-label">Fee Range</span>
                                                <strong>{exam.fees}</strong>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="exam-card-actions">
                                        <button className="btn-primary" style={{ background: exam.color }}>Register Now</button>
                                        <button className="btn-outline" style={{ color: exam.color, borderColor: exam.color }}>
                                            Details <ChevronRight size={14} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </div>
        </PageTransition>
    );
};

export default Exams;
